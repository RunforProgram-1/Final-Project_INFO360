// app.js

const form = document.getElementById("form");
const list = document.getElementById("user-list");
const message = document.getElementById("message");
const loadBtn = document.getElementById("loadBtn");

// GET all users
async function getUsers() {
  list.innerHTML = "⏳ Loading...";

  try {
    const res = await fetch("/api/items");

    if (!res.ok) {
      throw new Error("Failed to fetch users");
    }

    const data = await res.json();

    if (!data.length) {
      list.innerHTML = "No users found.";
      return;
    }

    list.innerHTML = data.map(user => `
      <div class="user-card">
        <p><strong>${user.name}</strong></p>
        <p>${user.email}</p>
        <p>${user.city}</p>
      </div>
    `).join("");

  } catch (err) {
    console.error(err);
    list.innerHTML = "❌ Error loading users.";
  }
}

// POST new user
form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const user = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    city: document.getElementById("city").value
  };

  if (!user.name || !user.email || !user.city) {
    message.textContent = "❌ All fields are required";
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

if (!emailRegex.test(user.email)) {
  message.textContent = "❌ Please enter a valid email address";
  return;
}

  message.textContent = "⏳ Adding user...";

  try {
    const res = await fetch("/api/items", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(user)
    });

    if (!res.ok) {
      throw new Error("Failed to add user");
    }

    await res.json();

    message.textContent = "✅ User added successfully!";
    form.reset();

    getUsers(); // refresh list

  } catch (err) {
    console.error(err);
    message.textContent = "❌ Error adding user.";
  }
});

// Load users button
loadBtn.addEventListener("click", getUsers);