// app.js
const express = require("express");
const path = require("path");

const app = express();

// Middleware
app.use(express.json());

// Debug middleware 
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// Frontend stored in "public" folder
app.use(express.static(path.join(__dirname, "public")));


// Fake database
let items = [];

// GET all users
app.get("/api/items", (req, res) => {
  res.json(items);
});

// POST new user
app.post("/api/items", (req, res) => {
  console.log("REQ BODY RECEIVED:", req.body); // 

  const { name, email, city } = req.body;

  // Validation
  if (!name || !email || !city) {
    console.log("❌ Missing fields detected");
    return res.status(400).json({ error: "Missing required fields" });
  }

  const newItem = {
    id: items.length + 1,
    name,
    email,
    city
  };

  items.push(newItem);

  console.log("✅ User added:", newItem);

  return res.status(201).json(newItem);
});

// Environment variable
const APP_NAME = process.env.APP_NAME || "My App";

// Start server
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});